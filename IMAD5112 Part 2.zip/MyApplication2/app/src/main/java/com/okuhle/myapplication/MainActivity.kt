package com.okuhle.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var edtTextNumber1 = findViewById<EditText>(R.id.edtTextNumber1)
        var edtTextNumber2 = findViewById<EditText>(R.id.edtTextNumber2)

        var edtTextMainAnswer = findViewById<TextView>(R.id.edtTextMainAnswer)



        val btnAddition = findViewById<Button>(R.id.Add)
        btnAddition.setOnClickListener {

            var Number1 : Int = edtTextNumber1.text.toString().toInt()
            var Number2 : Int = edtTextNumber2.text.toString().toInt()

            var additionAnswer = Number1 + Number2

            edtTextMainAnswer.text = String.format("$Number1+$Number2=$additionAnswer")

        }

        Subtract.setOnClickListener {

            var Number1 : Int = edtTextNumber1.text.toString().toInt()
            var Number2 : Int = edtTextNumber2.text.toString().toInt()

            var SubtractionAnswer = Number1 - Number2

            edtTextMainAnswer.text = String.format("$Number1"+"-"+"$Number2"+"="+"$SubtractionAnswer")

        }

        var btnMultiply = null
        btnMultiply.setOnClickListener {

            var Number1 : Int = edtTextNumber1.text.toString().toInt()
            var Number2 : Int = edtTextNumber2.text.toString().toInt()

            var MultiplicationAnswer = Number1 * Number2

            String.format("$Number1×$Number2=$MultiplicationAnswer")
                .also { edtTextMainAnswer.text = it }

        }

        var btnDivision = null
        btnDivision.setOnClickListener {

            var Number1 : Int = edtTextNumber1.text.toString().toInt()
            var Number2 : Int = edtTextNumber2.text.toString().toInt()

            var DivisionAnswer = Number1 / Number2

            String.format("$Number1"+"÷"+"$Number2"+"="+"$DivisionAnswer")
                .also { edtTextMainAnswer.text = it }

        }


    }
}
}
    }
}